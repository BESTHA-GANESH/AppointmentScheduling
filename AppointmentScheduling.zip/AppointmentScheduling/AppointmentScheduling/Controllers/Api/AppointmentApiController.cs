﻿using AppointmentScheduling.Models.viewmodels;
using AppointmentScheduling.services;
using AppointmentScheduling.Utility;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Security.Claims;

namespace AppointmentScheduling.Controllers.Api
{
    [Route("api/Appointment")]
    [ApiController]
    public class AppointmentApiController : Controller
    {
        private readonly IAppointmentservice appointmentservice;
        private readonly IHttpContextAccessor httpContextAccessor; 
        private readonly string loginUserId;
        private readonly string role;
        public AppointmentApiController(IAppointmentservice appointmentservice)
        {
            appointmentservice = appointmentservice;
            httpContextAccessor = httpContextAccessor;
            loginUserId = httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            role = httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
        }
        [HttpPost]
        [Route("SaveCalendarData")]
        public IActionResult SaveCalendarData(Appointmentvm data)
        {
            Commonresponse<int> commonresponse = new Commonresponse<int>();
            try
            {
                commonresponse.status = appointmentservice.AddUpdate(data).Result;
                if(commonresponse.status == 1)
                {
                    commonresponse.message = Helper.appointmentUpdated;
                }
                if(commonresponse.status == 2)
                {
                    commonresponse.message = Helper.appointmentAdded;
                }
            }
            catch(Exception e)
            {
                commonresponse.message=e.Message;
                commonresponse.status = Helper.failure_code;
            }
            return Ok(commonresponse);
        }
    }
} 
