﻿using AppointmentScheduling.services;
using AppointmentScheduling.Utility;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.InteropServices;

namespace AppointmentScheduling.Controllers
{
    public class AppointmentController : Controller
    {

        private readonly IAppointmentservice _appointmentservice;

        public AppointmentController(IAppointmentservice appointmentService)
        {
            _appointmentservice = appointmentService;
        }

        public IActionResult Index()
        {

            ViewBag.Duration = Helper.GetTimeDropDown();
            ViewBag.DoctorList = _appointmentservice.GetDoctorList();
            ViewBag.PatientList = _appointmentservice.GetPatientList();

            return View();
        }
    }
}