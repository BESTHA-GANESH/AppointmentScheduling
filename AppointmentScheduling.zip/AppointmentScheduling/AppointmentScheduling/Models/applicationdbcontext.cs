﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AppointmentScheduling.Models
{
    public class applicationdbcontext:IdentityDbContext<ApplicationUser>
    {
        public applicationdbcontext(DbContextOptions<applicationdbcontext> options) : base(options) { }
        public DbSet<Appointment> Appointments { get; set; }
        
    }
}
