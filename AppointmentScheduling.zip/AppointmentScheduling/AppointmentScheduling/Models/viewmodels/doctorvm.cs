﻿namespace AppointmentScheduling.Models.viewmodels
{
    public class doctorvm
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
