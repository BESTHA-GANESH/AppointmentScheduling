﻿namespace AppointmentScheduling.Models.viewmodels
{
    public class patientvm
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
