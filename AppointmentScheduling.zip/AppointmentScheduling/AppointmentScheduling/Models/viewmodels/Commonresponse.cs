﻿namespace AppointmentScheduling.Models.viewmodels
{
    public class Commonresponse<T>
    {
        public int status { get; set; }
        public string message { get; set; }
        public T dataenum { get; set; }
    }
}
