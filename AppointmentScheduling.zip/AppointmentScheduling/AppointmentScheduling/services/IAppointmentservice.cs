﻿using AppointmentScheduling.Models.viewmodels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppointmentScheduling.services
{
    public interface IAppointmentservice
    {
        public List<doctorvm> GetDoctorList();
        public List<patientvm> GetPatientList();
        public Task<int> AddUpdate(Appointmentvm model);

    }
}
